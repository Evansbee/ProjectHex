
var width;
var height;
var mouseX;
var mouseY;
var cameraX;
var cameraY;

var cam;
var hm;

function handleKeyboardPress(e)
{
	if(!e) //fuck internet explorer
	{
		e = window.event;
	}
	
	if(e.keyCode == 37) // left
	{
		cam.LeftPressed();
		
	}
	if(e.keyCode == 38) // up
	{
		cam.UpPressed();
	}
	if(e.keyCode == 39) // right
	{
		cam.RightPressed();
	}
	if(e.keyCode == 40) // down
	{
		cam.DownPressed();
	}
}
function handleKeyboardRelease(e)
{
	if(!e) //fuck internet explorer
	{
		e = window.event;
	}
	
	if(e.keyCode == 37) // left
	{
		cam.LeftReleased();
		
	}
	if(e.keyCode == 38) // up
	{
		cam.UpReleased();
	}
	if(e.keyCode == 39) // right
	{
		cam.RightReleased();
	}
	if(e.keyCode == 40) // down
	{
		cam.DownReleased();
	}
}

function updateMouse(e)
{
	//reason why javascript blows -- does this even work in IE?
	if (e.layerX || e.layerX == 0) {
		mouseX = e.layerX;
		mouseY = e.layerY;
	} else if (e.offsetX || e.offsetX == 0) {
		mouseX = e.offsetX;
		mouseY = e.offsetY;
	}
}


function setup()
{
	var canvas = document.getElementById('gwa');
	canvas.addEventListener("mousemove",updateMouse,false);
	
	document.addEventListener("keydown",handleKeyboardPress,false);
	document.addEventListener("keyup",  handleKeyboardRelease,false);
	
	
	cam = new camera(); 
	hm = new hex_manager(10,10,50);
	
	
	setInterval(draw,1000/30)
	
	width = 800;
	height = 450;
	
	
}  


function draw(){
	var canvas = document.getElementById('gwa');
	
	cam.Update();
	cameraX = cam.getX();
	cameraY = cam.getY();
	
	
	var div = document.getElementById('txt');
	div.innerHTML = "mx: " + mouseX + " my: " + mouseY + " cx: " + cameraX + " cy: " + cameraY;
	if (canvas.getContext){
		var ctx = canvas.getContext('2d');
		
		ctx.clearRect(0,0,width,height);
		ctx.fillStyle = 'rgba(128,128,128,1)';
		ctx.fillRect(0,0,width,height);
		
		
		
		ctx.save();
		ctx.translate(cameraX,cameraY);
		hm.Update(mouseX-cameraX,mouseY-cameraY);
		
		hm.Display(ctx);
		ctx.restore();
	}
}